import stdio
import sys

n=int(sys.argv[1])

X=n//1000
Y=n//100%10
stdio.writeln('%d  %d' %(X, Y))