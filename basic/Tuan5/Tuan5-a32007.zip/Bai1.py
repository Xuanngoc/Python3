import sys
import stdio

stdio.writeln('Nhap so can kiem tra: ')
n=int(stdio.readInt())

i=2
if n<2:
	stdio.writeln('%d khong phai la so nguyen to' %n)
elif n==2:
	stdio.writeln('2 la so nguyen to') 	
else:
	for i in range(i, n):

		if n%i==0:

			print('%d khong phai la so nguyen to' %n)
			break
	else: 
		print('%d la so nguyen to' %n)
		

		
		
			

		

			


