import stdio
import sys

#nhap 4 so tu nien

# stdio.write('Nhap so thu nhat = ')
# a = stdio.readInt()
# stdio.write('Nhap so thu hai = ')
# b = stdio.readInt()
# stdio.write('Nhap so thu ba = ')
# c = stdio.readInt()
# stdio.write('Nhap so thu tu = ')
# d = stdio.readInt()

a = int(sys.argv[1])
b = int(sys.argv[2])
c = int(sys.argv[3])
d = int(sys.argv[4])


max = a
if b > max:
	max = b
if c > max:
	max = c
if d > max:
	max = d

stdio.writeln('max = ' + str(max))			
